package com.example.trme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CreateToDo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_to_do);
    }
}